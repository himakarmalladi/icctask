<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'icc_wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '=kxv ?I1,X_eye|0skfUauV&hEQeeBr(R>X (~F^,BK]){H=/}(,)0.Gu/VDR7ZD' );
define( 'SECURE_AUTH_KEY',  'Av-<H*d57*tt;Tb!+Ls;;=Z1PG6Hih8f1veDcrl~HV=2lF{|g~;4kg;V4<q5r?R?' );
define( 'LOGGED_IN_KEY',    '^_>s/#zM=rIaB6.BOos).ur2_zCGO3N;tQ|C3Z7FlAx`,=L] $O-Cgt3gWnUc1z$' );
define( 'NONCE_KEY',        'a`YZ&)fqfX|bn#(_mP4ieV,@-p>[7$`|sZFFUD:mGRV{m|qK;D~!W{a}dC`y@Qv8' );
define( 'AUTH_SALT',        'K7|?Yimlf},KaH6jmS.kjbgv7b,36j50wV-!W:X{t+MlE6bLNUl/Nx}(x(OiEAy8' );
define( 'SECURE_AUTH_SALT', 'vRmeXG&s@HSy*jx4B,vjC-3k*wcn^}7Fu:CQ]I.P`+qG;c.W-!Nv>ON]GH9%R{2n' );
define( 'LOGGED_IN_SALT',   '|[L1~0w:SVx@n(R`8S0w:.ExGTQ(g*A/<c?wysV?d1+](d=4n$,JP*uT[@Wnab1l' );
define( 'NONCE_SALT',       '*5rDL9yIB!{)x(E @tx+02e24P7F|P+=C-t9_6fU5V8]KC<;9Jc`Z9E~zB-gY%%a' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
